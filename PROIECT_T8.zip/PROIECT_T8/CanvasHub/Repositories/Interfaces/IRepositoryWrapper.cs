﻿using CanvasHub.Repositories.Interfaces;
using CanvasHub.Models;

namespace CanvasHub.Repositories.Interfaces
{
    public interface IRepositoryWrapper 
    {

        void Save();

    }
}
