﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanvasHub.Migrations
{
    /// <inheritdoc />
    public partial class Event1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
