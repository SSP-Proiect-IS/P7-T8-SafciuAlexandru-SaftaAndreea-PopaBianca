﻿//namespace CanvasHub.Services.Interfaces
//{
//    public interface IReportService
//    {
//        Task<PaymentsReport> GeneratePaymentsReportAsync();
//        Task<ProfitReport> GenerateProfitReportAsync();
//        Task<List<ResourceCalendarReport>> GenerateResourceCalendarReportAsync();
//        Task<List<ResourceAvailabilityReport>> GenerateResourceAvailabilityReportAsync(DateTime startDate, DateTime endDate);
//    }
//}
