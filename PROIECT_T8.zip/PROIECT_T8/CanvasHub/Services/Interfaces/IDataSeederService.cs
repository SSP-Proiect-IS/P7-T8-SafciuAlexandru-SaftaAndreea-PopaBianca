﻿namespace CanvasHub.Services.Interfaces
{
    public interface IDataSeederService
    {
        Task SeedRolesAndAdminAsync();
    }
}
